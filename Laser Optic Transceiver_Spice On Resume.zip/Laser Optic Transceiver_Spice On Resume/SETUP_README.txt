Required setup options for new DXDesigner installation.

Setup->Settings->Schematic Editor->New Sheets
Check Automatically add borders on new schematic
Check Enable user-configurable border symbols
Check Use sheet 1 border for underlying schematics

Setup->Settings->Advanced
Check Unique names on copy
